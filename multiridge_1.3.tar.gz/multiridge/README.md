# multiridge
R package for multi-penalty ridge regression

library(devtools);
install_github("markvdwiel/multiridge")

Demo script and data available from: https://drive.google.com/open?id=1NUfeOtN8-KZ8A2HZzveG506nBwgW64e4

